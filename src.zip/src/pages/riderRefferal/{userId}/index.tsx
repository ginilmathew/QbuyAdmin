import { type } from 'os'
import React from 'react'

// type params = {
//     params:{
//         userId:string
//     }
// }

const RiderRefferalView = () => {
  return (
    <div>
      
    </div>
  )
}

export default RiderRefferalView
