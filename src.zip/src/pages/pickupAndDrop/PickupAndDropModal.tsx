import React from 'react'

const PickupAndDropModal = () => {
  return (
    <div>PickupAndDropModal</div>
  )
}

export default PickupAndDropModal